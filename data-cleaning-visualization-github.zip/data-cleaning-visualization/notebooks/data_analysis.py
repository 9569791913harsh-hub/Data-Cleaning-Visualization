import pandas as pd

df = pd.read_csv("data/cleaned_sales_data.csv", parse_dates=["Order Date"])
print("Shape:", df.shape)
print(df.describe(include="all"))
print("\nSales by Category:")
print(df.groupby("Category")["Sales"].sum().sort_values(ascending=False))
print("\nSales by Region:")
print(df.groupby("Region")["Sales"].sum().sort_values(ascending=False))
