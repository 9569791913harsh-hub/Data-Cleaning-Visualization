# Data Cleaning & Visualization — Project Report

## Objective
Transform a raw retail dataset into a reliable analytical dataset and communicate insights through visualizations and an interactive dashboard.

## Cleaning
The pipeline handles missing values, duplicates, invalid numerical values, and IQR-based outliers. Numerical missing values use median imputation, categorical values use mode imputation, and detected outliers are capped rather than blindly deleted.

## Analysis
The project analyzes sales by category and region, monthly sales trends, category profitability, quantity distributions, and correlations among numerical variables.

## Dashboard
The Streamlit dashboard provides KPI cards, interactive Region/Category filters, charts, a correlation heatmap, dataset preview, and CSV download.

## Learning Outcomes
- Data preprocessing with Pandas
- Statistical analysis
- Outlier treatment
- Data visualization
- Interactive dashboard development
- Data storytelling
