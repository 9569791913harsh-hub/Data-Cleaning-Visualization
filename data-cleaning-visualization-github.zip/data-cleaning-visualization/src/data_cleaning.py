from pathlib import Path
import pandas as pd
import numpy as np

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_FILE = BASE_DIR / "data" / "raw_sales_data.csv"
CLEAN_FILE = BASE_DIR / "data" / "cleaned_sales_data.csv"

def clean_data(df):
    df = df.copy()
    report = {
        "initial_rows": len(df),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_before": int(df.isna().sum().sum())
    }

    df["Order Date"] = pd.to_datetime(df["Order Date"], errors="coerce")
    df = df.drop_duplicates()

    for col in df.select_dtypes(include="object").columns:
        if df[col].isna().any():
            mode = df[col].mode()
            df[col] = df[col].fillna(mode.iloc[0] if not mode.empty else "Unknown")

    for col in df.select_dtypes(include=np.number).columns:
        df[col] = df[col].fillna(df[col].median())

    df["Quantity"] = df["Quantity"].clip(lower=1)
    df["Unit Price"] = df["Unit Price"].clip(lower=0)
    df["Sales"] = (df["Quantity"] * df["Unit Price"]).round(2)

    outliers = {}
    for col in ["Quantity", "Unit Price", "Sales", "Profit"]:
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        if iqr == 0:
            outliers[col] = 0
            continue
        lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
        mask = (df[col] < lower) | (df[col] > upper)
        outliers[col] = int(mask.sum())
        df[col] = df[col].clip(lower, upper)

    df["Sales"] = (df["Quantity"] * df["Unit Price"]).round(2)
    df = df.sort_values("Order Date").reset_index(drop=True)
    report["missing_after"] = int(df.isna().sum().sum())
    report["final_rows"] = len(df)
    report["outliers_detected"] = outliers
    return df, report

if __name__ == "__main__":
    raw = pd.read_csv(RAW_FILE)
    cleaned, report = clean_data(raw)
    cleaned.to_csv(CLEAN_FILE, index=False)
    print("DATA CLEANING COMPLETE")
    for k, v in report.items():
        print(f"{k}: {v}")
    print(f"Saved: {CLEAN_FILE}")
