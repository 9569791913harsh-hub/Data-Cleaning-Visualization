from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "data" / "cleaned_sales_data.csv"
OUT_DIR = BASE_DIR / "visualizations"
OUT_DIR.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid")

def save(name):
    plt.tight_layout()
    plt.savefig(OUT_DIR/name, dpi=160, bbox_inches="tight")
    plt.close()

df = pd.read_csv(DATA_FILE, parse_dates=["Order Date"])

df.groupby("Category")["Sales"].sum().sort_values().plot(kind="barh", figsize=(8,5))
plt.title("Sales by Category"); plt.xlabel("Sales"); save("sales_by_category.png")

df.groupby("Region")["Sales"].sum().sort_values().plot(kind="bar", figsize=(8,5))
plt.title("Sales by Region"); plt.ylabel("Sales"); save("sales_by_region.png")

df.set_index("Order Date").resample("MS")["Sales"].sum().plot(figsize=(10,5), marker="o")
plt.title("Monthly Sales Trend"); plt.ylabel("Sales"); save("monthly_sales_trend.png")

df.groupby("Category")["Profit"].sum().sort_values().plot(kind="bar", figsize=(8,5))
plt.title("Profit by Category"); plt.ylabel("Profit"); save("profit_by_category.png")

df["Quantity"].plot(kind="hist", bins=15, figsize=(8,5))
plt.title("Quantity Distribution"); plt.xlabel("Quantity"); save("quantity_distribution.png")

plt.figure(figsize=(8,6))
sns.heatmap(df.select_dtypes("number").corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Heatmap"); save("correlation_heatmap.png")
print(f"Charts saved to {OUT_DIR}")
