# 📊 Data Cleaning & Visualization Project

A complete Python data analytics project that cleans a raw retail sales dataset, performs exploratory data analysis, generates visualizations, and provides an interactive Streamlit dashboard.

## Features
- Missing-value analysis and treatment
- Duplicate detection and removal
- IQR-based outlier detection and capping
- Data type conversion and validation
- Exploratory data analysis
- Sales, profit, region and category visualizations
- Correlation heatmap
- Interactive Streamlit dashboard
- Filtered CSV download

## Tech Stack
Python • Pandas • NumPy • Matplotlib • Seaborn • Streamlit

## Quick Start

```bash
git clone https://github.com/YOUR_USERNAME/data-cleaning-visualization.git
cd data-cleaning-visualization
pip install -r requirements.txt
python src/data_cleaning.py
python src/visualization.py
streamlit run dashboard/app.py
```

## Workflow
**Raw Data → Cleaning → Processing → Analysis → Visualization → Dashboard → Insights**

## Dataset
The included synthetic retail dataset intentionally contains missing values, duplicate records, and extreme observations for demonstrating data-cleaning techniques.

## Author
**Your Name** — replace this with your GitHub/college details.
