# Generated Charts

Run `python src/visualization.py` to generate the six PNG charts in this folder.
