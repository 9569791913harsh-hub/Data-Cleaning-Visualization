from pathlib import Path
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "data" / "cleaned_sales_data.csv"

st.set_page_config(page_title="Sales Analytics Dashboard", page_icon="📊", layout="wide")
st.title("📊 Sales Data Cleaning & Visualization Dashboard")
st.caption("Interactive analysis of the cleaned retail sales dataset")

if not DATA_FILE.exists():
    st.error("Run `python src/data_cleaning.py` first.")
    st.stop()

df = pd.read_csv(DATA_FILE, parse_dates=["Order Date"])

st.sidebar.header("Filters")
regions = st.sidebar.multiselect("Region", sorted(df.Region.unique()), default=sorted(df.Region.unique()))
categories = st.sidebar.multiselect("Category", sorted(df.Category.unique()), default=sorted(df.Category.unique()))
filtered = df[df.Region.isin(regions) & df.Category.isin(categories)].copy()

orders = filtered["Order ID"].nunique()
avg_order = filtered.groupby("Order ID").Sales.sum().mean() if orders else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Total Sales", f"${filtered.Sales.sum():,.2f}")
c2.metric("Total Profit", f"${filtered.Profit.sum():,.2f}")
c3.metric("Total Orders", f"{orders:,}")
c4.metric("Avg. Order Value", f"${avg_order:,.2f}")

left,right = st.columns(2)
with left:
    st.subheader("Sales by Category")
    st.bar_chart(filtered.groupby("Category").Sales.sum())
with right:
    st.subheader("Sales by Region")
    st.bar_chart(filtered.groupby("Region").Sales.sum())

st.subheader("Monthly Sales Trend")
st.line_chart(filtered.set_index("Order Date").resample("MS").Sales.sum())

left,right = st.columns(2)
with left:
    st.subheader("Profit by Category")
    st.bar_chart(filtered.groupby("Category").Profit.sum())
with right:
    st.subheader("Quantity Distribution")
    fig,ax=plt.subplots()
    ax.hist(filtered.Quantity, bins=15)
    ax.set_xlabel("Quantity"); ax.set_ylabel("Frequency")
    st.pyplot(fig)

st.subheader("Correlation Heatmap")
fig,ax=plt.subplots(figsize=(9,5))
sns.heatmap(filtered.select_dtypes("number").corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
st.pyplot(fig)

st.subheader("Cleaned Dataset Preview")
st.dataframe(filtered.head(100), use_container_width=True)

st.download_button(
    "⬇️ Download Filtered CSV",
    filtered.to_csv(index=False).encode("utf-8"),
    "filtered_sales_data.csv",
    "text/csv"
)
